## Homework 1

> _**Submission**: Sept 4, 2022_

### Usage

- For any problem `i`,

```bash
ghci
> :load i.hs
> -- test the function loaded from the file
```

, or simply load the `combined.hs` file to test all functions at once


```bash
ghci
> :load combined.hs
> -- test all functions loaded from the file
```
